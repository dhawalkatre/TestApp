import React from 'react';

const AdminDash = () => {
	return(
        
	);
}
      
export default AdminDash;