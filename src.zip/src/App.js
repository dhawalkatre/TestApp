import React from 'react';
import './App.css';
import Navigator from './screens/Navigator.js';

function App() {
  return (
    <Navigator/>
  );
}

export default App;
